# J0kers 1v1.lol Menu

Thanks For Downloading J0kers 1v1.lol Menu! This mod enhances your gameplay experience with a variety of powerful features to give you a cheating advantage in the game. Whether you're looking to fly, boost your speed, or gain god-like abilities, this menu has it all.

## Requirements

[![.Net 6.0](https://img.shields.io/badge/Net-6.0-blue?style=for-the-badge)](https://dotnet.microsoft.com/en-us/download/dotnet/thank-you/sdk-6.0.428-windows-x64-installer)
[![Melon Loader (6.6)](https://img.shields.io/badge/MelonLoader-green?style=for-the-badge)](https://github.com/LavaGang/MelonLoader.Installer/releases/download/4.1.1/MelonLoader.Installer.exe)

## Features

### **Visual**
- **Box ESP**
- **Wire Frame ESP**
- **Body ESP**
- **Bone ESP**
- **Tracers**

### **Player**
- **Fly**
- **Speed Boost**
- **Spin Bot**
- **God Mode**

### **Weapon**
- **Aim Bot**
- **Infinite Ammo**
- **Rapid Fire**
- **Weapon Level Max**

### **Server**
- **Spawn Materials**
- **Spawn Ammo**
- **Spawn Player**
- **Spawn Shadow Clone**
- **Destroy All Builds**
- **Open All Loot Boxes**
- **Win Game**

## Installation

1. Download and install **Mellon Loader** if you haven't already.
2. Download the **J0kers1v1LOLMenu.dll** mod in releases.
3. Put the DLL into the **Mellon Loader Mods** folder.
4. Launch the game through Steam, and the menu will be available in-game.

## Usage

- **Open Menu**: Press **TAB** to open the menu in-game.
- Once the menu is open, you can toggle each feature on or off using the menu interface.
- When In Game Press ALT To Show Your Mouse Cursor

## Disclaimer

This mod is intended for educational purposes and personal use. Using this mod in online multiplayer games may result in a ban or other penalties. Use at your own risk!
# Find More
[![Visit Website](https://img.shields.io/badge/Visit-J0kerModZ.lol-blue?style=for-the-badge)](https://www.j0kermodz.lol)
